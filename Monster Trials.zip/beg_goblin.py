from random import randrange
import entity

class BegGoblin(entity.Entity):
    def __init__(self):
        super().__init__("Goblin", randrange(7, 10))
    def melee_attack(self, enemy):
        dmg = randrange(4, 7)
        if (enemy._hp > 0):
            enemy.take_dmg(dmg)
            return f"{self._name} has smashed a mallet dealing {dmg} damage to {enemy.get_name}!\n"