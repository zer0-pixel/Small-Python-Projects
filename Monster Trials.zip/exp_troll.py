from random import randrange
import entity
class ExpTroll(entity.Entity):
    def __init__(self):
        super().__init__("Enhanced Troll", randrange(15, 19))
    def melee_attack(self, enemy):
        dmg = randrange(8, 13)
        if (enemy._hp > 0):
            enemy.take_dmg(dmg)
            return f"{self._name} has chomped {enemy.get_name}'s arm, dealing {dmg} damage!\n"