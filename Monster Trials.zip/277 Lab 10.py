"""
Author: Thomas Johnson, Linh Dong
Date: 4/15/2025
Program: User fights monsters 
"""
from beg_factory import Beginner_Factory
from exp_factory import ExpertFactory
import entity
import hero


def main():
    beg_factory = Beginner_Factory()
    exp_factory = ExpertFactory()
    begMonsters = [beg_factory.create_random_enemy() for _ in range(2)]
    expMonsters = [exp_factory.create_random_enemy() for _ in range(1)]

    print("Monster Trials")
    name =  input("What is your name? ")
    user = hero.Hero(name)

    print(f"\nYou will face a series of 3\n"
          f"monsters, {name}.\n"
          f"Defeat them all to win.\n")

    print("Choose an enemy to attack:")
    while user.get_hp > 0 and (len(begMonsters) > 0 or len(expMonsters) > 0):
        for i, gobl_trl in enumerate((begMonsters + expMonsters), start=1):
            print(f"{i}. {gobl_trl}")
        try:
            user_choice = int(input("Enter Choice: "))
            if 1 <= user_choice <= len(begMonsters + expMonsters):
                enemy = (begMonsters + expMonsters)[user_choice - 1]
            else:
                print("Invalid Input. Choose 1 - 3")
                continue
        except ValueError:
            print("Invalid Number. Numbers only.")
            continue

        print(f"\n{user}")

        try:
            weapon = int(input("1. Sword\n"
                               "2. Bow and Arrow\n"
                               "Enter Choice: "
                               ))
            if weapon == 1:
                sword = user.melee_attack(enemy)
                print(sword)
            elif weapon == 2:
                bow = user.ranged_attack(enemy)
                print(bow)
            else:
                print("Invalid Input. Choose 1 - 2\n")
                continue
        except ValueError:
            print("Invalid Input. Input a number.\n")
            continue

        if enemy.get_hp > 0:
            enemy_atk = enemy.melee_attack(user)
            print(enemy_atk)
        else:
            print(f"{enemy.get_name} has been defeated!\n")
            if enemy in begMonsters:
                begMonsters.remove(enemy)
            elif enemy in expMonsters:
                expMonsters.remove(enemy)
    if all(e.get_hp <= 0 for e in  begMonsters + expMonsters):
        print("You've Won! You've defeated all three monsters!")
        print("Game Over")
    if user.get_hp <= 0:
        print(f"{user.get_name} has fallen!")
        print("Game Over")
        return
main()