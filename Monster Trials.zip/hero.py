from entity import Entity
from random import randrange
class Hero(Entity):
    def __init__(self, name):
        super().__init__(name, hp=25)
    def melee_attack(self, enemy):
        dmg = randrange(2, 7)
        if (enemy._hp > 0):
            enemy.take_dmg(dmg)
            return f"\n{self._name} has swung a sword, dealing {dmg} damage to {enemy.get_name}!"
        else:
            return f"\n{self._name} has taken down {enemy.get_name}!"
    def ranged_attack(self, enemy):
        dmg = randrange(1, 13)
        if (enemy._hp > 0):
            enemy.take_dmg(dmg)
            return f"\n{self._name} has pierced an arrow dealing {dmg} damage to {enemy.get_name}!"
        else:
            return f"\n{self._name} has taken down {enemy.get_name}!"




