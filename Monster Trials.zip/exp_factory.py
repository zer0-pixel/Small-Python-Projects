from enemy_factory import Enemy_Factory
import random
from exp_goblin import ExpGoblin
from exp_troll import ExpTroll

class ExpertFactory(Enemy_Factory):
    def create_random_enemy(self):
        exp_enemies = [ExpGoblin, ExpTroll]
        return random.choice(exp_enemies)()

