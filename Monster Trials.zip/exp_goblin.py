from random import randrange
import entity
class ExpGoblin(entity.Entity):
    def __init__(self):
        super().__init__("Enhanced Goblin", randrange(12, 16))
    def melee_attack(self, enemy):
        dmg = randrange(5, 9)
        if (enemy._hp > 0):
            enemy.take_dmg(dmg)
            return f"{self._name} has slammed {enemy.get_name}, dealing {dmg}!\n"