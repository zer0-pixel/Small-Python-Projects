from random import randrange
import entity
class BegTroll(entity.Entity):
    def __init__(self):
        super().__init__("Troll", randrange(8, 10))
    def melee_attack(self, enemy):
        dmg = randrange(5, 10)
        if (enemy._hp > 0):
            enemy.take_dmg(dmg)
            return f"{self._name} has punched {enemy.get_name}, dealing {dmg} damage!\n"