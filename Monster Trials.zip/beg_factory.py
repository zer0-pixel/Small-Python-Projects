from enemy_factory import Enemy_Factory
import random
from beg_troll import BegTroll
from beg_goblin import BegGoblin

class Beginner_Factory(Enemy_Factory):
    def create_random_enemy(self):
        beg_enemies = [BegGoblin, BegTroll]
        return random.choice(beg_enemies)()

