"""
Author: Thomas Johnson. Lihn Dong
Date: 4/23/2025
Program: Allows user to pick a character, choose items, and attempt to battle in 3 trials.
"""
from sympy.polys.domains.characteristiczero import CharacteristicZero
from monsters import Monster
from character import Character
import Decorator
from cloak import Cloak
from ring import Ring
from shield import Shield
from bard import Bard
from warrior import Warrior
from wizard import Wizard
import random

def main():
    # Character Objects
    characters = {1 : Bard(), 2 : Warrior(), 3 : Wizard()}
    #Item Objects
    items = [("Protective Cloak",Cloak), ("Magic Ring", Ring), ("Shielded", Shield)]
    print("Character Maker!")
    # Users input
    user_input = int(input(f"Choose a starting character: \n"
                           f"1. Bard\n"
                           f"2. Warrior\n"
                           f"3. Wizard\n"
                           "> "))
    # Catch users input
    if user_input in characters:
        character = characters[user_input]
        print(character)
    else:
        print("Invalid Input! Enter numbers 1 - 3.")
        return
    # Prompt user to pick 2 items
    print("Choose 2 items:")
    # Repeats item list twice, but pops the last picked item from the list
    for _ in range(2):
        for index, item in enumerate(items, start=1):
            print(f"{index}. {item[0]}")

        item_input = int(input("> "))
        if 1 <= item_input <= len(items):
            item_select = items[item_input - 1]
            item_class = item_select[1]
            character = item_class(character)
            items.pop(item_input - 1)
            print(character)
        else:
            print("Invalid Input! Enter number 1 - 3")
            return
    # Trial objects
    Trials = 3
    passed = 0
    failed = 0
    # Trial monsters
    Tri_monsters = [Monster("Orc Warlord", 1, 5),
                    Monster("Shadow Knight", 2, 4),
                    Monster("Lava Monster", 3, 3),
                    Monster("Fiendish Ghoul", 4, 2),
                    Monster("Goblin Mage", 5, 1),
                    Monster("Dark Magician", 6, 0)
                    ]
    options = ["Battle", "Dodge"]
    print("\nYou must pass two of the following three trials!")
    while Trials > 0:
        # Subtract to increase trial number
        print(f"\nTrial {4 - Trials} of 3: ")
        # Randomize trial monsters
        trial = random.choice(Tri_monsters)
        print(f"You encountered a {trial.name}")
        print(trial)

        print("Fight: ")
        # Option list prompted to user, ranging 1 - 2
        for index, option in enumerate(options, start=1):
            print(f"{index}. {option}")
        option_input = int(input("> "))
        # Checks if user has better stats than the monster
        if option_input == 1:
            if character.magic_resistance() >= trial.magic_resistance() and character.strength() >= trial.strength():
                print(f"You battle with the {trial.name} and easily defeat it.")
                print("You have passed this trial.")
                passed += 1
            else:
                print(f"You battle with the {trial.name} and lost the battle.")
                print("You have failed this trial.")
                failed += 1
        # 25% chance to dodge the monsters attack
        elif option_input == 2:
            dodge = random.uniform(0, 1)
            if dodge <= 0.25:
                print(f"You dodged the {trial.name}'s attack.")
                passed += 1
            else:
                print(f"You failed to dodge and have been hit by the {trial.name}'s attack.")
                print("You have failed this trial.")
                failed += 1
        else:
            print("Invalid Input. Enter 1 or 2.")
            continue
        # Decreases trial numbers
        Trials -= 1
    # Checks if two trials have passed or failed
    if passed >= 2:
        print("\nYou have passed the three trials...barely.")
    else:
        print("\nYou did not pass enough trials...")



main()