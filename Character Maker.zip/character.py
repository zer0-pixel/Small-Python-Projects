import abc
class Character(abc.ABC):
    @abc.abstractmethod
    def description(self):
        pass
    @abc.abstractmethod
    def magic_resistance(self):
        pass
    @abc.abstractmethod
    def strength(self):
        pass
    def __str__(self):
        return (f"Name: {self.name}\n"
                f"MR: {self.MR}\n"
                f"STR: {self.STR}")