from Decorator import Decorator
class Cloak(Decorator):
    def __init__(self, c):
        super().__init__(c)
        self.name = f"Cloaked {self.character.name}"
    def description(self):
        return super().description() + "A protective cloak"
    def magic_resistance(self):
        return super().magic_resistance() + 1
    def strength(self):
        return super().strength()
    def __str__(self):
        return (f"Name: {self.name}\n"
                f"MR: {self.magic_resistance()}\n"
                f"STR: {self.strength()}")

