from character import Character
class Monster(Character):
    def __init__(self, name, magic_resistance, strength):
        self.name = name
        self.MR = magic_resistance
        self.STR = strength

    def description(self):
        return f"{self.name} has {self.MR} magic resistance and {self.STR} strength."

    def magic_resistance(self):
        return self.MR

    def strength(self):
        return self.STR