from character import Character
class Bard(Character):
    def description(self):
        return "A guy who plays music"
    def magic_resistance(self):
        return 2
    def strength(self):
        return 2
    def __init__(self):
        self.name = "Bard"
        self.MR = self.magic_resistance()
        self.STR = self.strength()



