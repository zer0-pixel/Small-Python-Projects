import abc
from character import Character
class Decorator(Character, abc.ABC):
    def __init__(self, c):
        self.character = c
    def description(self):
        return self.character.description()
    def magic_resistance(self):
        return self.character.magic_resistance()
    def strength(self):
        return self.character.strength()
    def __str__(self):
        return f"{self.character}"
