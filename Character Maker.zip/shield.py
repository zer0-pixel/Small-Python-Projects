from Decorator import Decorator
class Shield(Decorator):
    def __init__(self, c):
        super().__init__(c)
        self.name = f"Shielded {self.character.name}"
    def description(self):
        return super().description() + "Increases Strength by 2"
    def magic_resistance(self):
        return super().magic_resistance()
    def strength(self):
        return super().strength() + 2
    def __str__(self):
        return (f"Name: {self.name}\n"
                f"MR: {self.magic_resistance()}\n"
                f"STR: {self.strength()}")