from character import Character
class Wizard(Character):
    def description(self):
        return "A teacher from hogwarts"
    def magic_resistance(self):
        return 3
    def strength(self):
        return 1
    def __init__(self):
        self.name = "Wizard"
        self.MR = self.magic_resistance()
        self.STR = self.strength()
