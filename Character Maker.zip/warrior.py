from character import Character
class Warrior(Character):
    def description(self):
        return "A strong man"
    def magic_resistance(self):
        return 0
    def strength(self):
        return 4
    def __init__(self):
        self.name = "Warrior"
        self.MR = self.magic_resistance()
        self.STR = self.strength()