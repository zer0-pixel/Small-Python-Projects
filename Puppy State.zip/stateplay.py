import puppystate
import state_asleep


class StatePlay(puppystate.PuppyState):
    # Returns a string
    def feed(self, puppy):
        return "\nThe puppy is too busy playing with the ball to eat right now."

    # Puppy state returns a string and plays with the puppy
    def play(self, puppy):
        puppy.inc_play()
        # Checks if play count is greater or equal to 2. If true, will go back to state_asleep.
        if puppy.play >= 2:
            puppy.change_state(state_asleep.StateAsleep())
            puppy.reset()
            return "\nYou throw the ball again and the puppy excitedly chases it.\nThe puppy played so much, it fell asleep!"
        return "\nYou throw the ball again and the puppy excitedly chases it."