import abc
class PuppyState(abc.ABC):
    # Turns feed methods into abstract methods
    @abc.abstractmethod
    def feed(self, puppy):
        pass
    # Turns play methods into abstract methods
    @abc.abstractmethod
    def play(self, puppy):
        pass