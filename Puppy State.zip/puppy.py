import state_asleep

class Puppy:
    # Initializes the state, feed and play
    def __init__(self):
        self._state = state_asleep.StateAsleep()
        self.feed = 0
        self.play = 0
    # feed becomes a state
    def get_feed(self):
        return self._state.feed(self)
    # play becomes a state
    def get_play(self):
        return self._state.play(self)
    # Switches states
    def change_state(self, new_state):
        self._state = new_state

    def throw_ball(self):
        return self.get_play()

    def give_food(self):
        return self.get_feed()
    # Increases feed count
    def inc_feed(self):
        self.feed += 1
    # Increases play count
    def inc_play(self):
        self.play += 1
    # Resets feed and play back to 0
    def reset(self):
        self.feed = 0
        self.play = 0
