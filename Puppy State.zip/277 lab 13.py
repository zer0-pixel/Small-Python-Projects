"""
Author: Thomas Johnson, Linh Dong
Date: 5/7/2025
Program: Uses State to allow user to feed and play with a digital puppy
"""
import puppy

def main():
    # Creates puppy object
    pup = puppy.Puppy()
    # List of options the user can pick from
    pup_care = ["Feed the puppy", "Play with the puppy", "Quit"]

    # Tomagachi game starts here
    print("Congratulations on your new puppy!")
    while True:
        print("What would you like to do?")
        # Creates listed items from pup_care list
        for p, list in enumerate(pup_care, start=1):
            print(f"{p}. {list}")
        # Prompts user for their choice
        user_input = input("Enter Choice: ")
        # Checks if users input is a letter or symbol
        try:
            # Converts users input to an integer
            user_input = int(user_input)
            # Checks users input
            if user_input == 1:
                print(pup.give_food())
            elif user_input == 2:
                print(pup.throw_ball())
            elif user_input == 3:
                print("Bye bye!")
                break
            else:
                # Checks if user is entering a number higher than 3
                print("\nInvalid Input! Input numbers 1 - 3.")
        except ValueError:
            print("\nThis is not a number!")

main()
