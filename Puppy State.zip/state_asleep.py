import puppystate
import state_eat

class StateAsleep(puppystate.PuppyState):
    # Puppy state changes to state_eat, resets the count, and returns a string
    def feed(self, puppy):
        puppy.change_state(state_eat.StateEat())
        puppy.reset()
        return "\nThe puppy wakes up and comes running to eat."
    # Returns a string
    def play(self, puppy):
        return "\nThe puppy is asleep and does not want to play right now."
