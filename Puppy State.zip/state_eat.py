import puppystate
import state_asleep
import stateplay

class StateEat(puppystate.PuppyState):
    # Puppy state returns a string and feeds puppy
    def feed(self, puppy):
        puppy.inc_feed()
        # Checks if feed count is greater or equal to 2. If true, will go back to state_asleep.
        if puppy.feed >= 2:
            puppy.change_state(state_asleep.StateAsleep())
            puppy.reset()
            return "\nThe puppy continues to eat as you add another scoop of kibble to its bowl.\nThe puppy ate so much, it fell asleep!"
        return "\nThe puppy continues to eat as you add another scoop of kibble to its bowl."

    # Returns a string and changes state to state_play
    def play(self, puppy):
        puppy.change_state(stateplay.StatePlay())
        return "\nThe puppy looks up from its food and chases the ball you threw."