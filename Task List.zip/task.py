import datetime

class Task:
    def __init__(self, desc, due_date, time):
        self.desc = desc
        self.due_date = datetime.datetime.strptime(due_date, "%m/%d/%Y").date()
        self.time = datetime.datetime.strptime(time, "%H:%M").time()

    def __str__(self):
        """Returns a formatted string displaying the task information."""
        return f"Task: {self.desc} | Due: {self.due_date} at {self.time}"

    def __repr__(self):
        """Returns a string representation for writing to a file."""
        return f"{self.desc},{self.due_date},{self.time}"

    def __lt__(self, other):
        """Compares tasks based on due date, time, and description."""
        return (self.due_date, self.time, self.desc) < (other.due_date, other.time, other.desc)