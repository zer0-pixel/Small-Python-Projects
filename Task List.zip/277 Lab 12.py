"""
Author: Thomas Johnson, Linh Dong
Date: 4/30/2025
Program: User gets to track their task list using this program
"""
import datetime
import task
from tasklist import TaskList
# Main menu display
def main():
    # Creating task manager object
    task_manager = TaskList()
    # Menu list
    tasklist = ["Display current task",
                "Display all task",
                "Mark current task complete",
                "Add new task",
                "Search by date",
                "Save and quit"]
    while True:
        print("-TaskList-")
        # Displays tasks uncompleted
        print(f"Tasks to Complete: {len(task_manager.tasklist)}")
        # Displays the task list
        for i, list in enumerate(tasklist, start=1):
            print(f"{i}. {list}")
        user = int(input(f"Enter choice: "))
        try:

            if user in range(1, len(tasklist) + 1):
                # Displays the current tasks
                if user == 1:
                    print('\n',task_manager.get_current_task(),'\n')

                # Displays all tasks
                elif user == 2:
                    print('\n')
                    for task in task_manager.tasklist:
                        print(task)
                    print('\n')

                # Marks upcoming task as complete
                elif user == 3:
                    print(f"\nMarking task as complete: \n"
                          f"{task_manager.get_current_task()}")
                    task_manager.mark_complete()
                    print(f"New current task: \n"
                          f"{task_manager.get_current_task()}\n")

                # Adds a task to the task list
                elif user == 4:
                    desc = input("Enter a Task: ")
                    date = get_date()
                    time = get_time()
                    if date and time:
                        task_manager.add_task(desc, date, time)
                        print("Task added.")

                # Searches for tasks by date
                elif user == 5:
                    print("Enter date to search: ")
                    month = input("Enter month: ")
                    day = input("Enter day: ")
                    year = input("Enter year: ")
                    try:
                        search_date = datetime.date(int(year), int(month), int(day))

                        results = [task for task in task_manager.tasklist if task.due_date == search_date]
                        if results:
                            print("Resulting Tasks: ")
                            for task in results:
                                print(task)
                        else:
                            print("Invalid Date!")
                    except ValueError:
                        print("Invalid Input!")
                # Saves task file
                elif user == 6:
                    task_manager.save_file()
                    print("\nTasks Saved\n")
            else:
                print("Invalid Selection!")
        except ValueError:
            print("Invalid Input!")

# Retrieves date from task class
def get_date():
    #Returns date for adding or searching for or by tasks
    while True:
        try:
            date_input = input("Enter the month, day, and year: ")
            month, day, year = map(int, date_input.split())
            if 1 <= month <= 12 and 1 <= day <= 31 and 2000 <= year <= 2100:
                return f"{month:02d}/{day:02d}/{year}"
            else:
                print("Invalid Date!")
        except ValueError:
            print("Valid months are 1-12, valid days are 1-31, and valid years are 2000-2100")

# Retrieves time from task class
def get_time():
    # Returns time for adding a task
    while True:
        try:
            time_input = input("(Military) Enter hour and minute: ")
            hour, minute = map(int, time_input.split())
            if 0 <= hour <= 23 and 0 <= minute <= 59:
                return f"{hour:02d}:{minute:02d}"
            else:
                print("Invalid Time!")
        except ValueError:
            print("Valid hours are 0-23 and valid minutes are 0-59")

if __name__ == "__main__":
    main()