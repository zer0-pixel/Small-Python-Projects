from task import Task
class TaskList:
    """
    Attributes:
        description - string of task
        date - MM/DD/YYYY
        time - HH:MM
    """
    def __init__(self):
        self.tasklist = []
        try:
            # Txt file on read
            with open('tasklist.txt', 'r') as file:
                for line in file:
                    task_data = line.strip().split(',')
                    if len(task_data) == 3:
                        description, due_date, time = task_data
                        task = Task(description, due_date, time)
                        self.tasklist.append(task)
            self.tasklist.sort(key=lambda x: (x.due_date, x.time))
        except FileNotFoundError:
            print("File not found.")

    # Add a task to txt file
    def add_task(self, desc, date, time):
        new_task = Task(desc, date, time)
        self.tasklist.append(new_task)
        self.tasklist.sort(key=lambda x: (x.due_date, x.time))

    # Retrieves upcoming task from txt file
    def get_current_task(self):
        return self.tasklist[0] if self.tasklist else None

    # Pops task from txt file if completed
    def mark_complete(self):
        return self.tasklist.pop(0) if self.tasklist else None

    # Saves txt file
    def save_file(self):
        # Txt file on write
        with open('tasklist.txt', 'w') as file:
            for task in self.tasklist:
                file.write(f"{task.desc}, {task.due_date}, {task.time}\n")
    def __len__(self):
        return len(self.tasklist)
    def __iter__(self):
        self.n = 0
        return self
    def __next__(self):
        if self.n >= len(self.tasklist):
            raise StopIteration
        task = self.tasklist[self.n]
        self.n += 1
        return task


